
package application;

/**
 *
 * 
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Chat_ClientServer implements Runnable {

	private Socket socket;
	private PrintWriter out = null, out1 = null;
	private BufferedReader in = null, in1 = null;
	private Scanner sc;
	private Emission em;
	private EmissionName emn;
	private Reception re;
	private ReceptionName ren;
	
	public Chat_ClientServer(Socket s){
		socket = s;
	}
	
	public void run() {
		try {
			out = new PrintWriter(socket.getOutputStream());
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			sc = new Scanner(System.in);
			
			if (Main.getTin() == 1){
				emn = new EmissionName(out);
				ren = new ReceptionName(in);
			} if (Main.getTin() == 0){
				re = new Reception(in);
				em = new Emission(out);
			}
		    
		} catch (IOException e) {
			System.err.println("The remote server is disconnected!");
		}
	}

}

