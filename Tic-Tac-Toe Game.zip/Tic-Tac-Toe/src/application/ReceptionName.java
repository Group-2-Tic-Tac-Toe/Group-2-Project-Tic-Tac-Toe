 
package application;

/**
 *
 *  
 */

import java.io.BufferedReader;
import java.io.IOException;

public class ReceptionName implements Runnable {

	private BufferedReader in;
	private String message = null;
	private String loc;

	public ReceptionName(BufferedReader in) {

		this.in = in;
	}

	public void run() {

		while (true) {
			try {

				loc = in.readLine();
			//	Main.setPlayer2Name(loc);
				System.out.println("The server location is :" + loc);

			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	}

}